import React from 'react';

function Inicio(){
    return (
        <>
        <div className='h3'>Buscanos en instagram como @facuforipatecnologia</div>
        </>
    )
}

export default Inicio;