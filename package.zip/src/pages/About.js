import React from 'react';
import Card from '../componentes/Card';
import perfil from '../perfil.png'

function About(){
    return (
        <>
        <Card titulo='@facuforipatecnologia' imagen={perfil} descripcion='Repara tu celular'/>
        </>
    )
}

export default About;