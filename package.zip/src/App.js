import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import './App.css';
import Inicio from './pages/Inicio';
import About from './pages/About';
import Products from './pages/Products';
import Contact from './pages/Contact';


function App() {
  return (
    <>
      <Router>
        <nav class="navbar navbar-expand-lg bg-body-tertiary">
          <div class="container-fluid">
            <Link to='/' className="nav-link">Inicio</Link>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                  <Link to='/contact' className='nav-link' >Contact</Link>
                </li>
                <li className="nav-item">
                  <Link to='/about' className='nav-link' >About</Link>
                </li>
                <li className="nav-item">
                  <Link to='/products' className='nav-link' >Products</Link>
                </li>
              </ul>
            </div>
          </div>
        </nav>

        <Routes>
          <Route path='/about' Component={About} >
          </Route>
          <Route path='/' Component={Inicio} >
          </Route>
          <Route path='/products' Component={Products} >
          </Route>
          <Route path='/contact' Component={Contact} >
          </Route>
        </Routes>
      </Router>
    </>
  );
}

export default App;
